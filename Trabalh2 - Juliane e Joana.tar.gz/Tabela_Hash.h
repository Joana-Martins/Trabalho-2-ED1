#ifndef HASH_H_
#define HASH_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/time.h>
#include "Padroniza_Palavra.h"

#define TAM_MAX 70
#define N 200
#define TAMALFABETO 256

typedef struct{
  char *Palavra;
  long int* Posicao;
  int qtd;
}Item;

typedef struct Celula* Apontador;
typedef struct Celula{
  Item *Item;
  Apontador Proximo;
}Celula;

typedef struct{
  Apontador Primeiro, Ultimo;
}Lista;

typedef unsigned Pesos[N][TAMALFABETO];

typedef Lista Dicionario[TAM_MAX];

void Gera_Pesos(Pesos pesos);

int Funcao_Hash(char* palavra, Pesos pesos);

void FLVazia(Lista *lista);

int Vazia(Lista lista);

void Inicializa_Hash(Dicionario hash);

void Ins(char* palavra, Lista *lista, FILE* arquivo);

void Insere_Hash(char* palavra, Pesos pesos, Dicionario hash, FILE *arquivo);

Apontador Pesquisa(char* palavra, Pesos pesos, Dicionario hash);

void Procura_Hash(char* palavra, Pesos pesos, Dicionario hash);

void Desaloca_Hash(Dicionario hash);

void Busca_Hash(char **arquivos, char *procura, int tam);

#endif //HASH_H_