#include "Lista_Encadeada.h"

TipoLista* Inicializa_Lista(){
  TipoLista *Lista = (TipoLista*)malloc(sizeof(TipoLista));
  Lista -> Primeiro = NULL;
  Lista -> Ultimo = Lista -> Primeiro;
  return Lista;
}

int Lista_Vazia(TipoLista *Lista){
  if (Lista -> Primeiro == NULL) return 1;
  else return 0;
}

void Insere_Lista(char *Palavra, TipoLista *Lista, FILE *Arquivo){
  if(Lista -> Primeiro == NULL){
    Lista -> Primeiro = (TipoApontador)malloc(sizeof(TipoCelula));
    Lista -> Primeiro -> Item = (TipoItem*)malloc(sizeof(TipoItem));
    Lista -> Primeiro -> Item -> Palavra = (char*)malloc(strlen(Palavra)+1 * sizeof(char));
    strcpy(Lista -> Primeiro -> Item -> Palavra, Palavra);
    Lista -> Primeiro -> Item -> Posicao = ftell(Arquivo);
    Lista -> Ultimo = Lista -> Primeiro;
    Lista -> Primeiro -> Proximo = NULL;
    Lista -> Ultimo -> Proximo = Lista -> Primeiro -> Proximo;
  }
  else{
    Lista -> Ultimo -> Proximo = (TipoApontador)malloc(sizeof(TipoCelula));
    Lista -> Ultimo = Lista -> Ultimo -> Proximo;
    Lista -> Ultimo -> Item = (TipoItem*)malloc(sizeof(TipoItem));
    Lista -> Ultimo -> Item -> Palavra = (char*)malloc(strlen(Palavra)+1 * sizeof(char));
    strcpy(Lista -> Ultimo -> Item -> Palavra, Palavra);
    Lista -> Ultimo -> Item -> Posicao = ftell(Arquivo);
    Lista -> Ultimo -> Proximo = NULL;
  }
}

void Procura_Lista(char* Palavra, TipoLista *Lista){
  TipoApontador aux;
  int contador = 0;
  aux = Lista -> Primeiro;
  if(aux==NULL){
    printf("\nPALAVRA NAO ENCONTRADA!\n");
    return;
  }
  while(aux != NULL){
    if(strcmp(aux -> Item -> Palavra, Palavra) == 0){
      // printf("%ld ", aux -> Item -> Posicao - strlen(Palavra) + 1);
      contador++;
    }
    aux = aux -> Proximo;
  }
  if(contador == 0) printf("PALAVRA NAO ENCONTRADA!\n");
}

void Desaloca_Lista(TipoLista *Lista){
  TipoApontador aux = Lista -> Primeiro;
  TipoApontador aux2;
  while(aux != NULL){
    aux2 = aux;
    aux = aux -> Proximo;
    free(aux2 -> Item -> Palavra);
    free(aux2 -> Item);
    free(aux2);
  }
  free(Lista);
}


 double Busca_Lista(char **Arquivos, char *Procura, int qtdArquivos){
  TipoLista *Lista = Inicializa_Lista();
  char *aux=malloc(47*sizeof(char));
  char *Palavra;
  FILE *Arquivo;
  clock_t	Ticks[2];
	Ticks[1] = 0;

  for(int i = 0; i < qtdArquivos; i++){
    Arquivo = fopen(Arquivos[i], "r");
    if(!Arquivo) printf("%s ARQUIVO INEXISTENTE\n", Arquivos[i]);
    else{
      Ticks[0] = clock();
      while(fscanf(Arquivo, "%s", aux) != EOF){
        Ticks[0] = clock();
        padroniza_Palavra(aux);
        Palavra=malloc(strlen(aux)+1);
        strcpy(Palavra,aux);
        Insere_Lista(Palavra, Lista, Arquivo);
        Ticks[0] = clock() - Ticks[0];
        Ticks[1] += Ticks[0];
        free(Palavra);
      }
      printf("%s ", Arquivos[i]);
      Procura_Lista(Procura, Lista);
      printf("\n");
      Desaloca_Lista(Lista);
      fclose(Arquivo);
      Lista = Inicializa_Lista();
    }
  }
  double Tempo = (Ticks[1] * 1000)/ CLOCKS_PER_SEC;
  Desaloca_Lista(Lista);
  free(aux);
  return Tempo;
}
