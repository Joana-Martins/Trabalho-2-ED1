#include "Procurar_Estruturas.h"

void procurar_estruturas(char *procurar, char **arquivos, int tam){
  //double Tempos[5];
  //clock_t Ticks[2];
/*
  Ticks[0] = clock();
  printf("Lista encadeada: \n");
  Busca_Lista(arquivos, procurar, tam);
  Ticks[1] = clock();
  Tempos[LISTAENCADEADA] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

  Ticks[0] = clock();
  printf("\nArvore Binária:\n");
  consulta_ArvBin(procurar, arquivos, tam);
  Ticks[1] = clock();
  Tempos[ARVOREBINARIA] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

  Ticks[0] = clock();
  printf("\nArvore Balanceada:\n");
  consulta_ArvAVL(procurar, arquivos, tam);
  Ticks[1] = clock();
  Tempos[ARVOREAVL] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

  Ticks[0] = clock();
  printf("\nArvore TRIES:\n");
  consulta_TRIE(procurar, arquivos, tam);
  Ticks[1] = clock();
  Tempos[ARVORETRIE] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;*/

  Busca_Hash(arquivos,procurar,tam);
/*
  printf("\nRELATORIO DE TEMPOS DE BUSCA\n");
  printf("Lista Encadeada - Tempo gasto: %g ms.\n",Tempos[LISTAENCADEADA]);
  printf("Arvore Binaria - Tempo gasto: %g ms.\n",Tempos[ARVOREBINARIA]);
  printf("Arvore AVL - Tempo gasto: %g ms.\n",Tempos[ARVOREAVL]);
  printf("Arvore TRIE - Tempo gasto: %g ms.\n",Tempos[ARVORETRIE]);
  printf("Tabela Hash - Tempo gasto: %g ms.\n",Tempos[HASH]);*/
}
