#include "Procurar_Estruturas.h"

void procurar_estruturas(char *procurar, char **arquivos, int tam){
  double carregamento_lista, carregamento_arvbin, carregamento_arvavl, carregamento_arvtrie;
  double Tempos[5];
  clock_t Ticks[2];
  Ticks[0] = clock();
  printf("Lista encadeada: \n");
  carregamento_lista = Busca_Lista(arquivos, procurar, tam);
  Ticks[1] = clock();
  Tempos[LISTAENCADEADA] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

  Ticks[0] = clock();
  printf("\nArvore Binária:\n");
  carregamento_arvbin = consulta_ArvBin(procurar, arquivos, tam);
  Ticks[1] = clock();
  Tempos[ARVOREBINARIA] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

  Ticks[0] = clock();
  printf("\nArvore Balanceada:\n");
  carregamento_arvavl = consulta_ArvAVL(procurar, arquivos, tam);
  Ticks[1] = clock();
  Tempos[ARVOREAVL] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

  Ticks[0] = clock();
  printf("\nArvore TRIES:\n");
  carregamento_arvtrie = consulta_TRIE(procurar, arquivos, tam);
  Ticks[1] = clock();
  Tempos[ARVORETRIE] = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;

  printf("\nRELATORIO DE TEMPOS DE BUSCA\n");
  printf("Lista Encadeada - Tempo de Carregamento: %g ms | Tempo Busca: %g ms.\n",carregamento_lista,Tempos[LISTAENCADEADA]-carregamento_lista);
  printf("Arvore Binaria - Tempo de Carregamento: %g ms | Tempo gasto: %g ms.\n",carregamento_arvbin,Tempos[ARVOREBINARIA]-carregamento_arvbin);
  printf("Arvore AVL - Tempo de Carregamento: %g ms | Tempo gasto: %g ms.\n",carregamento_arvavl,Tempos[ARVOREAVL] - carregamento_arvavl);
  printf("Arvore TRIE - Tempo de Carregamento: %g ms | Tempo gasto: %g ms.\n",carregamento_arvtrie, Tempos[ARVORETRIE] - carregamento_arvtrie);
}
