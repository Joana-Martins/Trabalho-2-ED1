#include "Arvore_AVL.h"

int altura_NO(struct NO* no) {
	if (no == NULL) {
		return -1;
	} else {
		return no->altura;
	}
}

int fatorBalanceamento_NO(struct NO* no) {
	if(no == NULL){
		return 0;
	}
	return altura_NO(no -> dir) - altura_NO(no -> esq);
}

int maior(int x, int y) {
	if (x > y) {
		return x;
	} else {
		return y;
	}
}

int estaVazia_ArvAVL(ArvBin *raiz) {
	if (raiz == NULL) {
		return 1;
	}
	if (*raiz == NULL) {
		return 1;
	}
	return 0;
}

int totalNO_ArvAVL(ArvBin *raiz) {
	if (raiz == NULL) {
		return 0;
	}
	if ((*raiz) == NULL) {
		return 0;
	}
	int alt_esq = totalNO_ArvAVL(&((*raiz)->esq));
	int alt_dir = totalNO_ArvAVL(&((*raiz)->dir));
	return (alt_esq + alt_dir + 1);
}

int altura_ArvAVL(ArvBin *raiz) {
	if (raiz == NULL) {
		return 0;
	}
	if (*raiz == NULL) {
		return 0;
	}
	int alt_esq = altura_ArvAVL(&((*raiz) -> esq));
	int alt_dir = altura_ArvAVL(&((*raiz)-> dir));
	if (alt_esq > alt_dir) {
		return (alt_esq + 1);
	} else {
		return (alt_dir + 1);
	}
}

struct NO* RotacaoLL(ArvBin *A) {
	struct NO *B;
	B = malloc(sizeof(struct NO));
	if (*A != NULL && B != NULL) {
		if ((*A)->dir != NULL && (*A)->esq !=NULL) {
			B = (*A) -> esq;
			(*A) -> esq = B -> dir;
			B -> dir = *A;

			(*A)->altura = maior(altura_NO((*A)->esq), altura_NO((*A)->dir))
					+ 1;
			B -> altura = maior(altura_NO(B->esq), (*A)->altura) + 1;
			//*A = B;
			return B;
		}
	}
	return NULL;
}

struct NO* RotacaoRR(ArvBin *A) {
	struct NO* B;
	B = malloc(sizeof(struct NO));
	if (*A != NULL) {
		if ((*A)->dir != NULL && (*A)->esq != NULL) {
			B = (*A) -> dir;
			(*A)->dir = B -> esq;
			B -> esq = (*A);
			(*A) -> altura = maior(altura_NO((*A)->esq), altura_NO((*A)->dir))
					+ 1;
			B -> altura = maior(altura_NO(B->dir), (*A) -> altura) + 1;
			//(*A) = B;
			return B;
		}
	}
	return NULL;
}

void RotacaoLR(ArvBin *A) {
	if (*A != NULL) {
		(*A) -> esq = RotacaoRR(&(*A)->esq);
		*A = RotacaoLL(A);
	}
}

void RotacaoRL(ArvBin *A) {
	if (*A != NULL) {
		(*A) -> dir = RotacaoLL(&(*A)->dir);
		*A = RotacaoRR(A);
	}
}


int insere_ArvAVL(ArvBin* raiz, char* palavra, FILE* l){
	int res = 0;
	if(*raiz == NULL){
		struct NO *novo;
		novo = (struct NO*) malloc(sizeof(struct NO));
		if (novo == NULL) {
			return 0;
		}
		novo -> info = (Info*) malloc(sizeof(Info));
		novo -> info -> palavra = malloc(47 * sizeof(char));
		strcpy(novo->info->palavra, palavra);
		novo -> info -> posicoes = (long int*) malloc(100000* sizeof(long int));
		novo -> info -> indice = 0;
		novo -> info -> posicoes[0] = 0;
		novo -> info -> posicoes[novo -> info -> indice ] = ftell(l);
		novo -> altura = 0;
		novo -> esq = NULL;
		novo -> dir = NULL;
		*raiz = novo;
		return 1;
	} else{
		if(strcasecmp(palavra, (*raiz) -> info -> palavra) < 0){
			res = insere_ArvAVL(&((*raiz)->esq),palavra,l);
			if(fatorBalanceamento_NO(*raiz) > 1){
				if(fatorBalanceamento_NO((*raiz)->dir) < 0){
					RotacaoRR(&(*raiz)->dir);
				}
				RotacaoLL(raiz);
			}else if (fatorBalanceamento_NO(*raiz) < -1){
				if(fatorBalanceamento_NO((*raiz)->esq) < 0){
					RotacaoLL(&(*raiz)->esq);
				}
				RotacaoRR(raiz);
			}
		} else if (strcasecmp(palavra, (*raiz) -> info -> palavra) > 0){
			res = insere_ArvAVL(&((*raiz)->dir),palavra,l);
			if(fatorBalanceamento_NO(*raiz) > 1){
				if(fatorBalanceamento_NO((*raiz)->dir) < 0){
					RotacaoRR(&(*raiz)->dir);
				}
				RotacaoLL(raiz);
			}else if (fatorBalanceamento_NO(*raiz) < -1){
				if(fatorBalanceamento_NO((*raiz)->esq) < 0){
					RotacaoLL(&(*raiz)->esq);
				}
				RotacaoRR(raiz);
			}
		}else{
			(*raiz) -> info -> indice++;
			// printf("%i\n", (*raiz) -> info -> indice++);
			(*raiz) -> info -> posicoes[(*raiz) -> info -> indice] = ftell(l);
			return 0;
		}
	}
	return res;
}


ArvBin* Procura_ArvAVL(ArvBin *raiz, char *procura) {
	if (*raiz == NULL) {
		return NULL;
	}
	if (strcasecmp(((*raiz) -> info -> palavra), procura) == 0) {
		return raiz;
	}
	if (strcasecmp(procura, (*raiz) -> info -> palavra) < 0) {
		return Procura_ArvAVL(&((*raiz)-> esq), procura);
	}
	if (strcasecmp(procura, (*raiz) -> info -> palavra) > 0) {
		return Procura_ArvAVL(&((*raiz)-> dir), procura);
	}
	return NULL;
}

double consulta_ArvAVL(char *procura, char **arquivos, int tam) {
	ArvBin *raiz = cria_ArvBin();
	FILE *l;
	char *aux = malloc(47 * sizeof(char));
	int i, j;
	clock_t	Ticks[2];
	Ticks[1] = 0;
	for (i = 0; i < tam; i++) {
		l = fopen(arquivos[i], "r");
		if (!l)
			printf("%s ARQUIVO INEXISTENTE\n", arquivos[i]);
		else {
			while (fscanf(l, "%s", aux) != EOF) {
				Ticks[0] = clock();
				padroniza_Palavra(aux);
				insere_ArvAVL(raiz, aux, l);
				Ticks[0] = clock() - Ticks[0];
				Ticks[1] += Ticks[0];
			}
			printf("%s ", arquivos[i]);
			ArvBin* arvProcura = Procura_ArvAVL(raiz,procura);
			if (Procura_ArvAVL(raiz, procura) != NULL) {
				for (j = 0; j < (*arvProcura)->info->indice + 1; j++) {
					printf("%ld ",(*arvProcura) -> info -> posicoes[j] - strlen(procura)+ 1);

				}
			} else {
				printf("PALAVRA NAO ENCONTRADA\n");
			}
			printf("\n");
			libera_ArvBin(raiz);
			fclose(l);
			raiz = cria_ArvBin();
		}
	}
	double Tempo = (Ticks[1] * 1000)/ CLOCKS_PER_SEC;
	libera_ArvBin(raiz);
	free(raiz);
	free(aux);
	return Tempo;
}
