#ifndef MENU_H_
#define MENU_H_

#include <stdio.h>
#include <stdlib.h>

int menu();

#endif //MENU_H_
