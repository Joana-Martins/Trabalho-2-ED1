#include "Procurar_Estruturas.h"

void procurar_estruturas(char *procurar, char **arquivos, int tam){
  printf("Lista encadeada: \n");
  Busca_Lista(arquivos, procurar, tam);
  printf("Arvore Binária:\n");
  consulta_ArvBin(procurar, arquivos, tam);
  printf("Arvore Balanceada:\n");
  consulta_ArvAVL(procurar, arquivos, tam);
  printf("Arvore TRIES:\n");
  consulta_TRIE(procurar, arquivos, tam);
  printf("Tabela Hash: \n");
  //Busca_Hash(arquivos,procurar,tam);
}
