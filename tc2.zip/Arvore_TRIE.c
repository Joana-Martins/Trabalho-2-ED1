#include "Arvore_TRIE.h"

ArvTRIE* acha_no() {
	ArvTRIE *no = NULL;
	no = (ArvTRIE*) malloc(sizeof(ArvTRIE));
	if (no != NULL) {
		int i;
		no -> flag = false;
		for (i = 0; i < 256; i++) {
			no -> filho[i] = NULL;
		}
		no -> p.indice = 0;
		no -> p.posicoes = NULL;
	}
	return no;
}

void insere(ArvTRIE *raiz, char *chave, FILE *f) {
	int nivel;
	int tam = strlen(chave);
	int index;

	ArvTRIE *p_no = raiz;
	if (p_no == NULL) {
		p_no = acha_no();
	}

	for (nivel = 0; nivel < tam; nivel++) {
		index = (int) chave[nivel];
		if(index >= 'A' && index <= 'Z'){
			index += 32;
		}
		if (!p_no->filho[index]) {
			p_no -> filho[index] = acha_no();
		}
		p_no = p_no -> filho[index];
	}
	p_no -> flag = true;
	if (p_no -> p.posicoes == NULL) {
		p_no -> p.posicoes = (long int*) malloc(1000*sizeof(long int));
		p_no -> p.indice = 0;
		p_no -> p.posicoes[p_no -> p.indice] = ftell(f);
	} else {
		p_no -> p.indice++;
		p_no -> p.posicoes[p_no -> p.indice] = ftell(f);
	}
}

ArvTRIE* procura_trie(ArvTRIE *raiz, char* chave) {
	int nivel;
	int tam = strlen(chave);
	int index;
	int i;
	for(i = 0;i < strlen(chave); i++){
		if(chave[i] >= 'A' && chave[i] <= 'Z'){
			chave[i] = chave[i] + 32;
		}
	}
	
	ArvTRIE *p_no = raiz;
	for (nivel = 0; nivel < tam; nivel++) {
		index = (int) chave[nivel];
		if (!p_no -> filho[index]) {
			return NULL;
		}
		p_no = p_no -> filho[index];
	}
	if (p_no != NULL && p_no -> flag) {
		return p_no;
	} else {
		return NULL;
	}
}

void libera_ArvTRIE(ArvTRIE *p_no) {
	if (p_no == NULL) {
		return;
	}
	for (int i = 0; i < 127; i++) {
		if (p_no -> filho[i] != NULL) {
			libera_ArvTRIE(p_no -> filho[i]);
		}
	}
	if (p_no -> p.posicoes != NULL) {
		free(p_no->p.posicoes);
	}
	free(p_no);
}

void consulta_TRIE(char *procura, char **arquivos, int tam) {
	ArvTRIE *raiz = acha_no();
	ArvTRIE *aux2;
	FILE *l;
	char *aux = malloc(47 * sizeof(char));
	int i;
	for (i = 0; i < tam; i++) {
		l = fopen(arquivos[i], "r");
		if (!l)
			printf("%s ARQUIVO INEXISTENTE\n", arquivos[i]);
		else {
			while (fscanf(l, "%s", aux) != EOF) {
				padroniza_Palavra(aux);
				insere(raiz, aux, l);
			}
			printf("%s ", arquivos[i]);
			aux2 = procura_trie(raiz, procura);
			if (aux2 != NULL) {
				for (int i = 0; i <= aux2->p.indice; i++) {
					printf("%ld ", aux2 ->p.posicoes[i] - strlen(procura) + 1);
				}
			} else {
				printf("posicao: %p\n ", aux2);
				printf("PALAVRA NAO ENCONTRADA!");
			}

			printf("\n");
			libera_ArvTRIE(raiz);
			fclose(l);
			raiz = acha_no();
		}
	}
	libera_ArvTRIE(raiz);
	//free(raiz);

	free(aux);
}
