#include "Tabela_Hash.h"

void Gera_Pesos(Pesos pesos){
    struct timeval semente;
    gettimeofday(&semente, NULL);
    srand((int)(semente.tv_sec + 1000000 * semente.tv_usec));
    for (int i = 0; i < N; i++)
        for (int j = 0; j < TAMALFABETO; j++)
            pesos[i][j] = 1 + (int)(10000.0 * rand() / (RAND_MAX + 1.0));
}

int Funcao_Hash(char* palavra, Pesos pesos){
    int i;
    unsigned int Soma = 0;
    for (i = 0; i < strlen(palavra); i++) Soma = Soma + pesos[i][(unsigned int)palavra[i]];
    return (Soma % TAM_MAX);
}

void FLVazia(Lista *lista){
    lista -> Primeiro = (Celula *)malloc(sizeof(Celula));
    lista -> Ultimo = lista -> Primeiro;
    lista -> Primeiro -> Proximo = NULL;
}

int Vazia(Lista lista){
    if(lista.Primeiro == lista.Ultimo) return 1;
    else return 0;
}

void Inicializa_Hash(Dicionario hash){
    for (int i = 0; i < TAM_MAX; i++) FLVazia(&hash[i]);
}

Apontador Pesquisa(char* palavra, Pesos pesos, Dicionario hash)
{ /* Obs.: TipoApontador de retorno aponta para o item anterior da lista */
  int i;
  Apontador Ap=(Apontador)malloc(sizeof(Celula));
  i = Funcao_Hash(palavra, pesos);
  if (Vazia(hash[i])==1) return NULL;  /* Pesquisa sem sucesso */
  else
  { Ap = hash[i].Primeiro;
    if ( Ap!= NULL ){
    while ( Ap->Proximo->Proximo != NULL && strncmp(palavra, Ap->Proximo->Item->Palavra, sizeof(char))) Ap = Ap->Proximo;

    if (!strncmp(palavra, Ap->Proximo->Item->Palavra, sizeof(char))) return Ap;
    }
    else return NULL;  /* Pesquisa sem sucesso */
  }
  return NULL;
}

void Ins(char* palavra, Lista *lista, FILE* arquivo){
    lista->Ultimo->Proximo = (Celula *)malloc(sizeof(Celula));
    lista->Ultimo = lista->Ultimo->Proximo;
    lista -> Ultimo -> Item = (Item*)malloc(sizeof(Item));
    lista -> Ultimo -> Item -> Palavra = (char*)malloc(strlen(palavra)+1 * sizeof(char));
    strcpy(lista -> Ultimo -> Item -> Palavra, palavra);
    lista->Ultimo->Item->Posicao = malloc(100000 * sizeof(long int));
    lista->Ultimo->Item->qtd=0;
    lista->Ultimo->Item->Posicao[lista->Ultimo->Item->qtd]=ftell(arquivo);
    lista->Ultimo->Item->qtd++;
}

void Insere_Hash(char* palavra, Pesos pesos, Dicionario hash, FILE *arquivo){
    int posicao=Funcao_Hash(palavra,pesos);
    if(Pesquisa(palavra,pesos,hash)==NULL) Ins(palavra, &hash[posicao],arquivo);
    else{
        Apontador aux=Pesquisa(palavra,pesos,hash)->Proximo;
        aux->Item->Posicao[aux->Item->qtd]=ftell(arquivo);
        aux->Item->qtd++;
    }
}

void Procura_Hash(char* palavra, Pesos pesos, Dicionario hash){
    if (Pesquisa(palavra,pesos,hash)==NULL) printf("\nPALAVRA NAO ENCONTRADA!\n");
    else{
        Apontador aux=Pesquisa(palavra,pesos,hash)->Proximo;
        for(int i=0;i<aux->Item->qtd+1;i++){
            printf("%ld ",aux->Item->Posicao[i] - strlen(palavra) + 1);
        }
    }
}
/*
void Desaloca_Hash(Dicionario hash){
    for (int i = 0; i < TAM_MAX; i++){
        if(Vazia(hash[i])==0) Desaloca_Lista(&hash[i]);
    }
}*/

void Busca_Hash(char **Arquivos, char *Procura, int qtdArquivos){
    Dicionario Hash;
    Inicializa_Hash(Hash);
    Pesos Pesos;
    Gera_Pesos(Pesos);
    char *aux=malloc(47*sizeof(char));
    char *Palavra;
    FILE *Arquivo;
    for(int i = 0; i < qtdArquivos; i++){
        Arquivo = fopen(Arquivos[i], "r");
        if(!Arquivo) printf("%s ARQUIVO INEXISTENTE\n", Arquivos[i]);
        else{
        while(fscanf(Arquivo, "%s", aux) != EOF){
            padroniza_Palavra(aux);
            Palavra=malloc(strlen(aux)+1);
            strcpy(Palavra,aux);
            Insere_Hash(Palavra,Pesos,Hash,Arquivo);
            free(Palavra);
        }
      printf("%s ", Arquivos[i]);
      Procura_Hash(Procura,Pesos,Hash);
      //Desaloca_Hash(Hash);
      fclose(Arquivo);
      Inicializa_Hash(Hash);
    }
  }
  //Desaloca_Hash(Hash);
  free(aux);
}
