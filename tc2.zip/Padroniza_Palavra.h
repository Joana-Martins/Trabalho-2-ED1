#ifndef PADRONIZA_PALAVRA_H_
#define PADRONIZA_PALAVRA_H_

#include <string.h>

void padroniza_Palavra(char* palavra);

#endif