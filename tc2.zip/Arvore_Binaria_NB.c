#include "Arvore_Binaria_NB.h"

ArvBin* cria_ArvBin() {
	ArvBin* raiz = (ArvBin*) malloc(sizeof(ArvBin));
	*raiz = NULL;
	return raiz;
}

int insere_ArvBin(ArvBin* raiz, char *p, FILE *f) {
	if (*raiz == NULL) {
		*raiz = malloc(sizeof(struct NO));
		(*raiz) -> dir = NULL;
		(*raiz) -> esq = NULL;
		(*raiz) -> info = (Info*) malloc(sizeof(Info));
		(*raiz) -> info -> palavra = (char*) malloc((strlen(p) + 1) * sizeof(char));
		strcpy((*raiz) -> info -> palavra, p);
		(*raiz) -> info -> posicoes = malloc(100000 * sizeof(long int));
		(*raiz) -> info -> indice = 0;
	}

	if (strcasecmp(p, (*raiz) -> info -> palavra) < 0) {
		return insere_ArvBin(&((*raiz)-> esq), p, f);
	}
	if (strcasecmp(p, (*raiz) -> info -> palavra) > 0) {
		return insere_ArvBin(&((*raiz)-> dir), p, f);
	}
	if (strcasecmp(p, (*raiz) -> info -> palavra) == 0) {
		(*raiz) -> info -> posicoes[(*raiz) -> info -> indice] = ftell(f);
		(*raiz) -> info -> indice++;
	}
	return 0;
}

void imprimirArvore(ArvBin arv) {
	if (arv != NULL) {
		printf("<%s", arv->info -> palavra);
		imprimirArvore(arv -> esq);
		imprimirArvore(arv -> dir);
	} else {
		printf("<");
	}
	printf(">");
}

void libera_NO(struct NO* no) {
	if (no == NULL) {
		return;
	}
	libera_NO(no ->esq);
	libera_NO(no->dir);
	free(no -> info -> palavra);
	free(no -> info -> posicoes);
	free(no-> info);
	free(no);
	no = NULL;
}

void libera_ArvBin(ArvBin *raiz) {
	if (*raiz == NULL) {
		return;
	}
	libera_NO(*raiz);
	free(raiz);
}

ArvBin*  Procura_ArvBin(ArvBin *raiz, char *procura) {
	if (*raiz == NULL) {
		return NULL;
	}
	if (strcasecmp(((*raiz) -> info -> palavra), procura) == 0) {
		return raiz;
	}
	if (strcasecmp(procura, (*raiz) -> info -> palavra) < 0) {
		return Procura_ArvBin(&((*raiz)-> esq), procura);
	}
	if (strcasecmp(procura, (*raiz) -> info -> palavra) > 0) {
		return Procura_ArvBin(&((*raiz)-> dir), procura);
	}
	return NULL;
}

void consulta_ArvBin(char *procura, char **arquivos, int tam) {
	ArvBin *raiz = cria_ArvBin();
	FILE *l;
	char *aux = malloc(47 * sizeof(char));
	int i;
	for (i = 0; i < tam; i++) {
		l = fopen(arquivos[i], "r");
		if (!l)
			printf("%s ARQUIVO INEXISTENTE\n", arquivos[i]);
		else {
			while (fscanf(l, "%s", aux) != EOF) {
				padroniza_Palavra(aux);
				insere_ArvBin(raiz, aux, l);
			}
			printf("%s ", arquivos[i]);
			ArvBin* arvProcura = Procura_ArvBin(raiz, procura);
			if (arvProcura != NULL) {
				for (int i = 0; i < (*arvProcura)->info->indice; i++) {
					printf(
							"%ld ",
							(*arvProcura) -> info -> posicoes[i] - strlen(procura)
									+ 1);
				}
			} else {
				printf("PALAVRA NAO ENCONTRADA!");
			}
			//imprimirArvore(*raiz);
			printf("\n");
			libera_ArvBin(raiz);
			fclose(l);
			raiz = cria_ArvBin();
		}
	}
	libera_ArvBin(raiz);
	free(raiz);
	free(aux);
}
