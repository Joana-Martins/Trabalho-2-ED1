#ifndef BIBLIOTECA_LEITURA_ARQUIVOS_H_
#define BIBLIOTECA_LEITURA_ARQUIVOS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char** matriz_arquivos(int argc, char *argv[]);

#endif //BIBLIOTECA_LEITURA_ARQUIVOS_H_
