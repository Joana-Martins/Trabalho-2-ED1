#include "menu.h"


int menu(){
  char opcao;

  puts("Escolha a opção abaixo: ");
  puts("(1) - Procurar uma plavra");
  puts("(2) - Procurar palavras geradas aleatoriamente");
  puts("(3) - Procurar todas as palavras");
  printf("Numero da opcao: ");
  scanf("%c", &opcao);
  while(opcao != '1' && opcao != '2' && opcao != '3'){
    puts("Opcao invalida");
    printf("Numero da opcao: ");
    scanf("%c", &opcao);
  }
  if(opcao == '1'){
    system("clear");
    return 1;
  }else if(opcao == '2'){
    system("clear");
    puts("Gerando palavras...");
    return 2;
  }else{
    system("clear");
    puts("Iniciando busca. Este processo pode demorar alguns segundos, nao pare o programa");
    return 3;
  }
}
