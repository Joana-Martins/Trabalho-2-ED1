#ifndef ARVORE_TRIE_H_
#define ARVORE_TRIE_H_
// #define CHAR_TO_INDEX(c) ((int)c - (int)'a')

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct posicao{
    int indice;
    long int *posicoes;
}Posicao;

typedef struct trie{
  struct trie*filho[256];
  Posicao p;
  bool flag;
}ArvTRIE;

ArvTRIE* acha_no();

void insere(ArvTRIE *raiz, char *chave, FILE *f);

ArvTRIE *procura_trie(ArvTRIE *raiz, char* chave);

void libera_ArvTRIE(ArvTRIE *raiz);

void consulta_TRIE(char *procura, char **arquivos, int tam);


#endif //ARVORE_TRIE_H_
