#include "Procurar_Estruturas.h"

void procurar_estruturas(char *procurar, char **arquivos, int tam){
  Item *i;
  i = criaPalavra(procurar);
  printf("Lista encadeada: \n");
  lista_de_busca(arquivos, i, tam);
  printf("Arvore Binária:\n");
  consulta_ArvBin(procurar, arquivos, tam);
  printf("Arvore Balanceada:\n");
  consulta_ArvAVL(procurar, arquivos, tam);
  printf("Arvore TRIES:\n");
  consulta_TRIE(procurar, arquivos, tam);
  printf("Tabela Hash: \n");
  free(i->palavra);
  free(i);
}
