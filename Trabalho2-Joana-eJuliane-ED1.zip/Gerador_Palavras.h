#ifndef GERADOR_PALAVRAS_H_
#define GERADOR_PALAVRAS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Padroniza_Palavra.h"

int ExistePalavra(char* palavra, char** palavras, int tam);

char **palavras_aleatorias(char **arquivos, int tam);

int palavras_todas(char **palavras, int tam, char **arquivos);

char **criar(int tam);

void liberar(char **palavras, int tam);

#endif //GERADOR_PALAVRAS_H_
