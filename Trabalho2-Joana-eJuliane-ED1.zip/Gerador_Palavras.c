#include "Gerador_Palavras.h"

int ExistePalavra(char* palavra, char** palavras, int tam){
  int contador=0;
  for(int i=0;i<tam;i++){
    if(strcmp(palavra,palavras[i])==0) contador++;
  }
  return contador;
}

char **palavras_aleatorias(char **arquivos, int tam){
  int i, j, count;
  int indice_aleatorio;
  char **aux = criar(1000000);
  char **palavras = (char**) malloc((100)*sizeof(char*));
  for(i = 0; i < 100; i++){
    palavras[i] = malloc(47*sizeof(char));
  }
  count = palavras_todas(aux, tam, arquivos);
  for(j = 0; j < 100; j++){
    indice_aleatorio = rand()%count;
    strcpy(palavras[j], aux[indice_aleatorio]);
    padroniza_Palavra(palavras[j]);
  }
  liberar(aux, 1000000);
  return palavras;
}

int palavras_todas(char **palavras, int tam, char **arquivos){
  int i, contador = 0;
  FILE *l;
  char *aux = malloc(47 * sizeof(char));
  for (i = 0; i < tam; i++) {
		l = fopen(arquivos[i], "r");
		if (!l)
			printf("%s ARQUIVO INEXISTENTE\n", arquivos[i]);
		else {
			while (fscanf(l, "%s", aux) != EOF) {
        padroniza_Palavra(aux);
        if(ExistePalavra(aux,palavras,contador)==0){
          strcpy(palavras[contador], aux);
          contador++;
        }
			}
    }
    fclose(l);
  }
  free(aux);
  return contador;
}

char **criar(int tam){
  int i;
  char **palavras = (char**) malloc(tam *sizeof(char*));
  for(i = 0; i<tam; i++){
    palavras[i] = malloc(47*sizeof(char));
  }
  return palavras;
}

void liberar(char **palavras, int tam){
  int i;
  for(i = 0; i<tam ; i++){
      free(palavras[i]);
    }
  free(palavras);
}
