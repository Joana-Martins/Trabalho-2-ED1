#ifndef PROCURAR_ESTRUTURAS_H_
#define PROCURAR_ESTRUTURAS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Lista_Encadeada.h"
#include "Biblioteca_Leitura_Arquivos.h"
#include "Arvore_Binaria_NB.h"
#include "Arvore_AVL.h"
#include "Arvore_TRIE.h"
#include "Tabela_Hash.h"
#define LISTAENCADEADA 0
#define ARVOREBINARIA 1
#define ARVOREAVL 2
#define ARVORETRIE 3
#define HASH 4

void procurar_estruturas();

#endif //PROCURAR_ESTRUTURAS_H_
