#include "Lista_Encadeada.h"
#include "Biblioteca_Leitura_Arquivos.h"
#include "Arvore_Binaria_NB.h"
#include "Arvore_AVL.h"
#include "Arvore_TRIE.h"
#include "Tabela_Hash.h"
#include "menu.h"
#include "Procurar_Estruturas.h"
#include "Gerador_Palavras.h"
#include <time.h>

int main(int argc, char* argv[]){
  int tam=argc-1, opcao;
  int i, j;
  char **arquivos = matriz_arquivos(argc, argv);
  char *procurar = malloc(47 * sizeof(char));
  char **palavras;
  opcao = menu();
  clock_t Ticks[2];
   Ticks[0] = clock();

   if(opcao == 1){
     printf("\nDigite a palavra a ser buscada: ");
     scanf(" %s", procurar);
     padroniza_Palavra(procurar);
     procurar_estruturas(procurar, arquivos, tam);
   }else if(opcao == 2){
     palavras = palavras_aleatorias(arquivos, tam);
     for(i = 0; i < 30; i++){
       strcpy(procurar, palavras[i]);
       printf("\nProcurando: %s\n",  palavras[i]);
       procurar_estruturas(procurar, arquivos, tam);
     }
     liberar(palavras, 30);
   }else if(opcao == 3){
     palavras = criar(1000000);
     j = palavras_todas(palavras, tam, arquivos);
     for(i = 0; i < j; i++){
       strcpy(procurar, palavras[i]);
       printf("\nProcurando: %s\n",  palavras[i]);
       procurar_estruturas(procurar, arquivos, tam);
     }
     liberar(palavras, 1000000);
   }else{
     printf("Erro inesperado\n");
   }

  free(procurar);
  for(int i=0;i<tam;i++)free(arquivos[i]);
  free(arquivos);
  Ticks[1] = clock();
  double Tempo = (Ticks[1] - Ticks[0]) * 1000.0 / CLOCKS_PER_SEC;
  printf("Tempo gasto: %g ms.", Tempo);
  printf("\n");
  return 0;
}
