#include "Biblioteca_Leitura_Arquivos.h"

char** matriz_arquivos(int *tam){
  int i=0;
  FILE *l;
  char opcao, *arquivo, **arquivos=malloc(100*sizeof(char*));
  arquivo = malloc(70 * sizeof(char));
  do{
    do{
      printf("\nDigite o nome do arquivo: ");
      scanf(" %s", arquivo);
      l=fopen(arquivo, "r");
      if(!l) printf("Tente novamente.");
    }while(!l);
    fclose(l);
    do{
      printf("\nDeseja adicionar novo arquivo? S/N : ");
      scanf(" %c", &opcao);
      if(opcao!='S' && opcao!='s' && opcao!='N' && opcao!='n') printf("Entrada invalida. Tente novamente.\n");
    }while(opcao!='S' && opcao!='s' && opcao!='N' && opcao!='n');
    system("clear");
    arquivos[i]=malloc((strlen(arquivo)+1));
    strcpy(arquivos[i],arquivo);
    i++;
  }while(opcao=='S' || opcao=='s');
  free(arquivo);
  *tam=i;
  return arquivos;
}