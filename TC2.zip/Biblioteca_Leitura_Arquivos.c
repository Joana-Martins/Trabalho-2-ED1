#include "Biblioteca_Leitura_Arquivos.h"

char** matriz_arquivos(){
  int i=1;
  FILE *l;
  char *arquivo, opcao, *aux;
  char **arquivos=(char**)malloc(100 * sizeof(char*));
  arquivos[0]=(char*)malloc(sizeof(char));
  do{
    aux = malloc(70 * sizeof(char));
    do{
      printf("\nDigite o nome do arquivo: ");
      scanf(" %s", aux);
      l=fopen(aux, "r");
      if(!l) printf("Tente novamente.");
    }while(!l);
    do{
      printf("\nDeseja adicionar novo arquivo? S/N : ");
      scanf(" %c", &opcao);
      if(opcao!='S' && opcao!='s' && opcao!='N' && opcao!='n') printf("Entrada invalida. Tente novamente.\n");
    }while(opcao!='S' && opcao!='s' && opcao!='N' && opcao!='n');
    system("clear");
    arquivo=malloc(strlen(aux)+1);
    arquivos[i]=malloc((strlen(aux)+1));
    strcpy(arquivo,aux);
    strcpy(arquivos[i],arquivo);
    i++;
    free(aux);
    free(arquivo);
  }while(opcao=='S' || opcao=='s');
  arquivos[0][0] = i;
  return arquivos;
}