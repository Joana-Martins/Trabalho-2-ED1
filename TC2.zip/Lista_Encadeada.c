#include "Lista_Encadeada.h"

TipoLista *FLVazia(){
  TipoLista *Lista;
  Lista = malloc(sizeof(TipoLista));
  Lista -> posicao = 0;
  Lista -> Primeiro = NULL;
  Lista -> Ultimo = Lista->Primeiro;
  return Lista;
}

int Vazia(TipoLista *Lista){
  return (Lista->Primeiro == Lista->Ultimo); //se vazia, retorna 0.
}

void Insere(Item *x, TipoLista *Lista){
if(Lista -> Primeiro == NULL){
  Lista -> posicao++;
  Lista -> Primeiro = (TipoApontador)malloc(sizeof(TipoCelula));
  Lista -> Primeiro -> item = x;
  Lista -> Primeiro -> item -> posicao = Lista -> posicao;
  Lista -> Ultimo = Lista -> Primeiro;
  Lista -> Primeiro -> Prox = NULL;
  Lista -> Ultimo -> Prox = Lista -> Primeiro -> Prox;
  return;
  }

  Lista -> posicao++;
  Lista -> Ultimo -> Prox = (TipoApontador)malloc(sizeof(TipoCelula));
  Lista -> Ultimo = Lista -> Ultimo -> Prox;
  Lista -> Ultimo -> item = x;
  Lista -> Ultimo -> item -> posicao = Lista -> posicao;
  Lista -> Ultimo -> Prox = NULL;
}

void Procura(TipoLista *Lista, Item *x){
  TipoApontador aux;
  int contador = 0;
  aux = Lista -> Primeiro;
  while(aux != NULL){
    if(strcmp(aux -> item -> palavra, x -> palavra) == 0){
      printf("%i ", aux -> item -> posicao);
      contador++;
    }
    aux = aux -> Prox;
  }
  if(contador == 0) printf("PALAVRA NAO ENCONTRADA!\n");
  else return;
}

Item* criaPalavra(char *palavra){
  Item* i;
  i = (Item*)malloc(sizeof(Item));
  i -> palavra = (char*)malloc((strlen(palavra)+1) * sizeof(char));
  strcpy(i -> palavra, palavra);
  return i;
}

void liberdade_lista(TipoLista *Lista){
  TipoApontador aux = Lista->Primeiro;
  TipoApontador aux2;
  while(aux != NULL){
    aux2 = aux;
    aux = aux->Prox;
    free(aux2->item->palavra);
    free(aux2 -> item);
    free(aux2);
  }
  free(Lista);
}

void lista_de_busca(char **arquivos, Item *procurando){
  TipoLista *lista;
  char *aux;
  char *palavra;
  int i;
  int tam = arquivos[0][0];
  FILE *l;
  Item *item = (Item*)malloc(sizeof(Item));
  for(i = 1; i < tam; i++){
    lista = FLVazia();
    aux=malloc(47*sizeof(char));
    l = fopen(arquivos[i], "r");
    while(fscanf(l, "%s", aux) != EOF){
      palavra=malloc(strlen(aux)+1);
      strcpy(palavra,aux);
      item = criaPalavra(palavra);
      Insere(item, lista);      
    }
    free(aux);
    printf("%s ", arquivos[i]);
    Procura(lista, procurando);
    printf("\n");
  }
  liberdade_lista(lista);
  free(palavra);
  for(i=0;i<tam;i++) free(arquivos[i]);
  free(arquivos);
  free(procurando);
}
