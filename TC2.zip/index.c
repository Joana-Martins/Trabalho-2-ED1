#include "Lista_Encadeada.h"
#include "Biblioteca_Leitura_Arquivos.h"

int main(int argc, char* argv[]){
  char **arquivos;
  char *procurar = malloc(47 * sizeof(char));
  Item *i;
  int tam;
  arquivos = matriz_arquivos(&tam);
  printf("\nDigite a palavra a ser buscada: ");
  scanf(" %s", procurar);
  i = criaPalavra(procurar);
  lista_de_busca(arquivos, i, tam);
  free(procurar);
  free(i->palavra);
  free(i);
  for(int i=0;i<tam;i++) free(arquivos[i]);
  free(arquivos);
  return 0;
}
