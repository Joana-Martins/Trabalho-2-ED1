#include "Lista_Encadeada.h"
#include "Biblioteca_Leitura_Arquivos.h"

int main(){
  char **arquivos;
  char *procurar = malloc(47 * sizeof(char));
  Item *i;
  arquivos = matriz_arquivos();
  printf("\nDigite a palavra a ser buscada: ");
  scanf(" %s", procurar);
  i = criaPalavra(procurar);
  lista_de_busca(arquivos, i);
  free(procurar);
  return 0;
}
